package com.products.assessment.service;

import com.products.assessment.entity.Product;
import com.products.assessment.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import com.products.assessment.exception.ProductNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public void addProduct(Product product) {
        productRepository.save(product);
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public Product getProductById(Integer id) throws ProductNotFoundException {
        Optional<Product> product = productRepository.findById(id);
        if (product.isEmpty()) {
            throw new ProductNotFoundException("Product not found with ID: " + id);
        }
        return product.get();
    }

    public List<Product> getAllProductsBetweenPrice(Double low, Double high) {
        return productRepository.findProductsBetweenPrice(low, high);
    }

    public void updateProduct(Integer id, Product product) throws ProductNotFoundException {
        if (!productRepository.existsById(id)) {
            throw new ProductNotFoundException("Product not found with ID: " + id);
        }
        product.setId(id);
        productRepository.save(product);
    }

    public void deleteProduct(Integer id) throws ProductNotFoundException {
        if (!productRepository.existsById(id)) {
            throw new ProductNotFoundException("Product not found with ID: " + id);
        }
        productRepository.deleteById(id);
    }
}
